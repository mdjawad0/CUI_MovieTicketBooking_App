package com.movie.simulator.customException;

public class InvalidSeatSelectionException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidSeatSelectionException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
